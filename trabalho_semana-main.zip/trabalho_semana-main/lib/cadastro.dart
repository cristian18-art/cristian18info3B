import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class TelaCadastro extends StatefulWidget {
  const TelaCadastro({super.key});

  @override
  State<TelaCadastro> createState() => _TelaCadastroState();
}

class _TelaCadastroState extends State<TelaCadastro> {
  final _nomeCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _senhaCtrl = TextEditingController();
  final _cursoCtrl = TextEditingController();
  final _fotoCtrl = TextEditingController();

  String _tipo = 'aluno';
  bool _carregando = false;

  Future<void> _cadastrar() async {
    if (_nomeCtrl.text.isEmpty || _emailCtrl.text.isEmpty || _senhaCtrl.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Preencha os campos obrigatórios (*)')),
      );
      return;
    }

    setState(() => _carregando = true);
    try {
      UserCredential cred = await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: _emailCtrl.text.trim(),
        password: _senhaCtrl.text.trim(),
      );

      // Salva no Firestore
      await FirebaseFirestore.instance.collection('usuarios').doc(cred.user!.uid).set({
        'nome': _nomeCtrl.text.trim(),
        'email': _emailCtrl.text.trim(),
        'tipo': _tipo,
        'curso': _tipo == 'aluno' ? _cursoCtrl.text.trim() : '',
        'fotoUrl': _fotoCtrl.text.trim(),
      });

      if (mounted) Navigator.pop(context);
    } on FirebaseAuthException catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.message ?? 'Erro no cadastro')),
        );
      }
    } finally {
      if (mounted) setState(() => _carregando = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Novo Cadastro')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(controller: _nomeCtrl, decoration: const InputDecoration(labelText: 'Nome Completo*')),
            TextField(controller: _emailCtrl, decoration: const InputDecoration(labelText: 'E-mail*')),
            TextField(controller: _senhaCtrl, obscureText: true, decoration: const InputDecoration(labelText: 'Senha*')),
            DropdownButtonFormField<String>(
              value: _tipo,
              items: const [
                DropdownMenuItem(value: 'aluno', child: Text('Aluno')),
                DropdownMenuItem(value: 'professor', child: Text('Professor')),
              ],
              onChanged: (v) => setState(() => _tipo = v!),
              decoration: const InputDecoration(labelText: 'Tipo de Conta'),
            ),
            if (_tipo == 'aluno')
              TextField(controller: _cursoCtrl, decoration: const InputDecoration(labelText: 'Curso/Turma')),
            TextField(controller: _fotoCtrl, decoration: const InputDecoration(labelText: 'Link da Foto (URL opcional)')),
            const SizedBox(height: 20),
            _carregando
                ? const CircularProgressIndicator()
                : ElevatedButton(onPressed: _cadastrar, child: const Text('Salvar Cadastro')),
          ],
        ),
      ),
    );
  }
}