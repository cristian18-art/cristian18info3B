import 'dart:async';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'login.dart';
import 'feedback.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: const FirebaseOptions(
      apiKey: "AIzaSyAnXxc37G6uIEBp0vi3_o5hSdGa0mQxgzs",
      authDomain: "pdm-c1-80062.firebaseapp.com",
      projectId: "pdm-c1-80062",
      storageBucket: "pdm-c1-80062.firebasestorage.app",
      messagingSenderId: "919537784528",
      appId: "1:919537784528:web:cfbb966b0fbb7fc64a70d5",
    ),
  );
  runApp(const MaterialApp(
    title: 'Portfólio MVP',
    debugShowCheckedModeBanner: false,
    home: RoteadorAutenticacao(),
  ));
}

class RoteadorAutenticacao extends StatefulWidget {
  const RoteadorAutenticacao({super.key});
  @override
  State<RoteadorAutenticacao> createState() => _RoteadorAutenticacaoState();
}

class _RoteadorAutenticacaoState extends State<RoteadorAutenticacao> {
  StreamSubscription<User?>? _sub;
  bool _carregando = true, _ehProfessor = false, _erro = false;
  User? _usuario;

  @override
  void initState() {
    super.initState();
    _sub = FirebaseAuth.instance.authStateChanges().listen((user) async {
      if (user == null) {
        if (mounted) setState(() { _usuario = null; _carregando = false; _erro = false; });
        return;
      }
      try {
        final doc = await FirebaseFirestore.instance.collection('usuarios').doc(user.uid).get();
        if (doc.exists && doc.data() != null) {
          if (mounted) setState(() { _usuario = user; _ehProfessor = doc.data()!['tipo'] == 'professor'; _carregando = false; });
        } else {
          if (mounted) setState(() { _erro = true; _carregando = false; });
        }
      } catch (_) {
        if (mounted) setState(() { _erro = true; _carregando = false; });
      }
    });
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_carregando) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if (_erro) return Scaffold(body: Center(child: ElevatedButton(onPressed: () => FirebaseAuth.instance.signOut(), child: const Text('Erro ao carregar dados. Sair'))));
    if (_usuario != null) return TelaPortfolio(alunoId: _ehProfessor ? null : _usuario!.uid, ehProfessor: _ehProfessor);
    return const TelaLogin();
  }
}