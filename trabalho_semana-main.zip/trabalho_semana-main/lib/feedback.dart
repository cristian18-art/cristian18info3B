import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class TelaPortfolio extends StatefulWidget {
  final String? alunoId;
  final bool ehProfessor;
  const TelaPortfolio({super.key, required this.alunoId, required this.ehProfessor});

  @override
  State<TelaPortfolio> createState() => _TelaPortfolioState();
}

class _TelaPortfolioState extends State<TelaPortfolio> {
  final _db = FirebaseFirestore.instance;
  String? _idAluno;
  String _nomeAluno = '';
  List<Map<String, dynamic>> _alunos = [], _projetos = [], _notas = [];

  @override
  void initState() {
    super.initState();
    _idAluno = widget.alunoId;
    if (widget.ehProfessor) _carregarAlunos();
    if (_idAluno != null) _carregarTudo();
  }

  Future<void> _carregarAlunos() async {
    final snap = await _db.collection('usuarios').where('tipo', isEqualTo: 'aluno').get();
    setState(() => _alunos = snap.docs.map((d) => {'id': d.id, 'nome': d['nome']}).toList());
  }

  Future<void> _carregarTudo() async {
    if (_idAluno == null) return;
    final u = await _db.collection('usuarios').doc(_idAluno).get();
    final p = await _db.collection('projetos').where('alunoId', isEqualTo: _idAluno).get();
    final n = await _db.collection('avaliacoes').where('alunoId', isEqualTo: _idAluno).get();
    setState(() {
      _nomeAluno = u.data()?['nome'] ?? '';
      _projetos = p.docs.map((d) => {'id': d.id, ...d.data()}).toList();
      _notas = n.docs.map((d) => d.data()).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.ehProfessor ? 'Visão do Professor' : 'Meu Portfólio de Projetos'),
        actions: [IconButton(icon: const Icon(Icons.exit_to_app), onPressed: () => FirebaseAuth.instance.signOut())],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (widget.ehProfessor)
            DropdownButtonFormField<String>(
              value: _idAluno, hint: const Text('Selecione um Aluno'),
              items: _alunos.map((a) => DropdownMenuItem(value: a['id'] as String, child: Text(a['nome'] ?? ''))).toList(),
              onChanged: (v) { setState(() => _idAluno = v); _carregarTudo(); },
            ),
          if (_idAluno != null) ...[
            Text(_nomeAluno, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const Divider(),
            const Text('Projetos', style: TextStyle(fontWeight: FontWeight.bold)),
            ..._projetos.map((p) => Card(child: ListTile(
              title: Text(p['titulo'] ?? ''),
              subtitle: Text('${p['descricao'] ?? ''}\nLink: ${p['link'] ?? ''}'),
              trailing: widget.ehProfessor ? IconButton(icon: const Icon(Icons.comment), onPressed: () => _modal(context, 'Feedback', (txt, _) async {
                await _db.collection('projetos').doc(p['id']).collection('comentarios').add({'texto': txt, 'autor': 'Professor'});
              })) : null,
            ))),
            const Divider(),
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              const Text('Notas', style: TextStyle(fontWeight: FontWeight.bold)),
              if (widget.ehProfessor) IconButton(icon: const Icon(Icons.add), onPressed: () => _modal(context, 'Nota', (d, n) async {
                await _db.collection('avaliacoes').add({'alunoId': _idAluno, 'disciplina': d, 'nota': double.tryParse(n) ?? 0});
                _carregarTudo();
              }, ehNota: true)),
            ]),
            ..._notas.map((n) => ListTile(title: Text(n['disciplina'] ?? ''), trailing: Text('${n['nota']}'))),
          ]
        ],
      ),
      floatingActionButton: (!widget.ehProfessor && _idAluno != null)
          ? FloatingActionButton(child: const Icon(Icons.add), onPressed: () => _modal(context, 'Projeto', (t, d) async {
              await _db.collection('projetos').add({'alunoId': _idAluno, 'titulo': t, 'descricao': d});
              _carregarTudo();
            }, ehNota: true))
          : null,
    );
  }

  void _modal(BuildContext ctx, String t, Function(String, String) onSave, {bool ehNota = false}) {
    final c1 = TextEditingController(), c2 = TextEditingController();
    showModalBottomSheet(context: ctx, builder: (_) => Padding(padding: const EdgeInsets.all(16), child: Column(mainAxisSize: MainAxisSize.min, children: [
      TextField(controller: c1, decoration: InputDecoration(labelText: ehNota ? 'Disciplina/Título' : 'Texto')),
      if (ehNota) TextField(controller: c2, decoration: const InputDecoration(labelText: 'Nota/Descrição')),
      ElevatedButton(onPressed: () { onSave(c1.text, c2.text); Navigator.pop(ctx); }, child: Text('Salvar $t'))
    ])));
  }
}