package com.example.trabalho_semana

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
